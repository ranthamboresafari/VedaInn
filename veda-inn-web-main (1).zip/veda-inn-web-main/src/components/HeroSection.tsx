
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Star, MapPin, Phone, Mail } from 'lucide-react';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

const HeroSection = () => {
  const heroImages = [
    {
      src: "https://images.unsplash.com/photo-1609920658906-8223bd289001",
      alt: "Ram Mandir Ayodhya"
    },
    {
      src: "https://images.unsplash.com/photo-1466442929976-97f336a657be",
      alt: "Sacred Temple Architecture"
    },
    {
      src: "https://images.unsplash.com/photo-1487958449943-2429e8be8625",
      alt: "Hotel Veda Inn Luxury"
    },
    {
      src: "https://images.unsplash.com/photo-1492321936769-b49830bc1d1e",
      alt: "Spiritual Ayodhya"
    }
  ];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Carousel */}
      <div className="absolute inset-0 z-0">
        <Carousel className="w-full h-full">
          <CarouselContent>
            {heroImages.map((image, index) => (
              <CarouselItem key={index}>
                <div className="relative w-full h-screen">
                  <img
                    src={image.src}
                    alt={image.alt}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/50"></div>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="absolute left-4 top-1/2 -translate-y-1/2 z-20" />
          <CarouselNext className="absolute right-4 top-1/2 -translate-y-1/2 z-20" />
        </Carousel>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center text-white">
        <div className="max-w-4xl mx-auto">
          {/* Star Rating */}
          <div className="flex justify-center items-center space-x-1 mb-4 animate-fade-in">
            {[...Array(4)].map((_, i) => (
              <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
            ))}
            <Star className="h-5 w-5 text-yellow-400" />
          </div>

          {/* Main Heading */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight animate-fade-in">
            Welcome to
            <span className="block text-yellow-400">Hotel Veda Inn</span>
          </h1>

          {/* Subheading */}
          <p className="text-xl md:text-2xl lg:text-3xl mb-8 text-gray-200 animate-fade-in">
            Experience Luxury & Comfort in the Heart of Faizabad, Near Ayodhya
          </p>

          {/* Description */}
          <p className="text-lg md:text-xl mb-8 max-w-3xl mx-auto text-gray-300 leading-relaxed animate-fade-in">
            Discover the perfect blend of modern amenities and traditional hospitality at Hotel Veda Inn. 
            Located conveniently in Faizabad with easy access to the holy city of Ayodhya, we offer 
            Super Deluxe rooms and Family Suites with world-class facilities.
          </p>

          {/* Contact Info */}
          <div className="flex flex-wrap justify-center items-center gap-6 mb-8 text-sm md:text-base animate-fade-in">
            <div className="flex items-center space-x-2">
              <Phone className="h-5 w-5 text-yellow-400" />
              <span>+91 77558 85539</span>
            </div>
            <div className="flex items-center space-x-2">
              <Mail className="h-5 w-5 text-yellow-400" />
              <span>info@hotelvedainn.com</span>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in">
            <a
              href="https://wa.me/917755885539"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-yellow-400 text-black hover:bg-yellow-500 text-lg px-8 py-3 rounded-lg font-medium transition-all duration-300 hover:shadow-lg transform hover:scale-105 inline-block"
            >
              Book Now
            </a>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-black text-lg px-8 py-3 transition-all duration-300 hover:shadow-lg transform hover:scale-105"
            >
              <Link to="/rooms">Explore Rooms</Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
