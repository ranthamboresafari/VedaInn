
import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Phone, Mail, Facebook, Twitter, Instagram, Wifi, Shield, Car, Utensils, Building, Headphones } from 'lucide-react';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const quickLinks = [
    { name: 'Home', path: '/' },
    { name: 'About Us', path: '/about' },
    { name: 'Ayodhya', path: '/ayodhya' },
    { name: 'Rooms', path: '/rooms' },
    { name: 'Dining', path: '/dining' },
    { name: 'Gallery', path: '/gallery' },
    { name: 'Contact Us', path: '/contact' },
  ];

  const policyLinks = [
    { name: 'Terms & Conditions', path: '/terms' },
    { name: 'Privacy Policy', path: '/privacy' },
    { name: 'Cancellation Policy', path: '/cancellation' },
  ];

  const facilities = [
    { icon: Wifi, name: 'Free WiFi' },
    { icon: Shield, name: '24hr Security' },
    { icon: Car, name: 'Free Parking' },
    { icon: Utensils, name: 'Restaurant' },
    { icon: Building, name: 'Elevator' },
    { icon: Headphones, name: 'Concierge Service' },
  ];

  return (
    <footer className="bg-gray-900 text-white">
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Hotel Info */}
          <div>
            <h3 className="text-2xl font-bold text-yellow-400 mb-4">Hotel Veda Inn</h3>
            <p className="text-gray-300 mb-4 leading-relaxed">
              Experience luxury and comfort in the heart of Faizabad with easy access to Ayodhya. 
              Your perfect destination for pilgrimage, business, and leisure.
            </p>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <MapPin className="h-4 w-4 text-yellow-400 flex-shrink-0" />
                <span className="text-sm">Fatehganj Devkali Rd, Deokali, Faizabad, UP 224001</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4 text-yellow-400" />
                <span className="text-sm">+91 77558 85539</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4 text-yellow-400" />
                <span className="text-sm">info@hotelvedainn.com</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xl font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.path}
                    onClick={scrollToTop}
                    className="text-gray-300 hover:text-yellow-400 transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Policies */}
          <div>
            <h4 className="text-xl font-semibold mb-4">Policies</h4>
            <ul className="space-y-2">
              {policyLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.path}
                    onClick={scrollToTop}
                    className="text-gray-300 hover:text-yellow-400 transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
            <div className="mt-6">
              <h5 className="font-semibold mb-2">Facilities</h5>
              <div className="grid grid-cols-2 gap-2">
                {facilities.map((facility, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <facility.icon className="h-3 w-3 text-yellow-400" />
                    <span className="text-xs text-gray-300">{facility.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Social & Newsletter */}
          <div>
            <h4 className="text-xl font-semibold mb-4">Connect With Us</h4>
            <div className="flex space-x-4 mb-6">
              <a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">
                <Facebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">
                <Twitter className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">
                <Instagram className="h-6 w-6" />
              </a>
            </div>
            <div>
              <h5 className="font-semibold mb-2">Book Direct & Save</h5>
              <p className="text-gray-300 text-sm mb-3">
                Contact us directly for the best rates and exclusive offers.
              </p>
              <a
                href="https://wa.me/917755885539"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-yellow-400 text-black px-4 py-2 rounded font-medium hover:bg-yellow-500 transition-colors text-sm inline-block"
              >
                Book on WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="border-t border-gray-800">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 Hotel Veda Inn. All rights reserved.
            </p>
            <p className="text-gray-400 text-sm mt-2 md:mt-0">
              Designed for comfort, built for memories.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
