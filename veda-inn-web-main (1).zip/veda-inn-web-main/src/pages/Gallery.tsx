
import React from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const Gallery = () => {
  const galleryCategories = [
    {
      title: 'Hotel Rooms & Suites',
      images: [
        {
          src: '/lovable-uploads/e5227926-ea9d-4dd8-b2b8-3ad3d3ac27b0.png',
          alt: 'Super Deluxe Room - King Size Bed with Premium Interiors'
        },
        {
          src: '/lovable-uploads/f418b3df-aa03-4895-93cd-7881ff4ebcd6.png',
          alt: 'Family Suite - Spacious Room with Modern Amenities'
        },
        {
          src: '/lovable-uploads/84b35ff5-c8e8-4fb4-8e8b-f147ba850db7.png',
          alt: 'Luxury Room - Elegant Design with Comfortable Seating'
        }
      ]
    },
    {
      title: 'Modern Bathrooms',
      images: [
        {
          src: '/lovable-uploads/a2af81c5-5e23-48ae-80ed-0eb7bbcab971.png',
          alt: 'Premium Bathroom - Modern Fittings with Marble Interiors'
        },
        {
          src: '/lovable-uploads/ac52a4c1-75ad-4ab2-a8ce-a48e524bb83c.png',
          alt: 'Luxury Bathroom - Contemporary Design with Quality Fixtures'
        }
      ]
    },
    {
      title: 'Hotel Facilities',
      images: [
        {
          src: '/lovable-uploads/597d0a37-e895-4b34-833e-541f1fa32ae9.png',
          alt: 'Modern Elevator - Convenient Access to All Floors'
        },
        {
          src: '/lovable-uploads/8753b457-676b-4f5d-84f0-caa8cf41b159.png',
          alt: 'Coffee Station - In-Room Tea and Coffee Facilities'
        }
      ]
    }
  ];

  const roomFeatures = [
    'King Size Beds with Premium Linens',
    'Air Conditioned Rooms with Individual Controls',
    'Modern Flat Screen TVs with Satellite Channels',
    'Free High-Speed WiFi Throughout the Property',
    'Contemporary Bathrooms with Hot Water Geyser',
    'Coffee Tables and Comfortable Seating Areas',
    'Spacious Wardrobes and Storage Solutions',
    'Elegant Interior Design with Marble Accents',
    'Modern Elevators for Easy Access',
    'In-Room Tea and Coffee Making Facilities'
  ];

  const hotelHighlights = [
    {
      title: 'Prime Location',
      description: 'Strategically located in Faizabad with easy access to Ayodhya temples and major attractions'
    },
    {
      title: 'Modern Architecture',
      description: 'Contemporary design with traditional hospitality, featuring elegant interiors and modern amenities'
    },
    {
      title: 'Comfort & Luxury',
      description: 'Every room designed for maximum comfort with premium furnishings and modern conveniences'
    },
    {
      title: 'Spiritual Ambiance',
      description: 'Peaceful environment perfect for pilgrims and families visiting the sacred city of Ayodhya'
    }
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-primary to-primary/80">
        <div className="container mx-auto px-4 pt-16">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Hotel Veda Inn Gallery
            </h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-8">
              Explore Our Beautiful Accommodations and Modern Facilities
            </p>
            <p className="text-lg max-w-4xl mx-auto leading-relaxed">
              Take a virtual tour of Hotel Veda Inn and discover the elegance, comfort, and modern amenities 
              that await you during your stay in Faizabad. From our luxurious rooms and suites to contemporary 
              bathrooms and hotel facilities, experience the quality and attention to detail that makes us 
              the preferred choice for pilgrims visiting Ayodhya.
            </p>
          </div>
        </div>
      </section>

      {/* Image Gallery */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {galleryCategories.map((category, categoryIndex) => (
            <div key={categoryIndex} className="mb-16">
              <div className="text-center mb-8">
                <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
                  {category.title}
                </h2>
                <div className="w-24 h-1 bg-primary mx-auto rounded"></div>
              </div>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {category.images.map((image, imageIndex) => (
                  <Card key={imageIndex} className="overflow-hidden hover:shadow-xl transition-all duration-300 group">
                    <div className="relative overflow-hidden">
                      <img
                        src={image.src}
                        alt={image.alt}
                        className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                        <Button variant="secondary" className="bg-white/90 text-gray-800 hover:bg-white">
                          View Full Size
                        </Button>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <p className="text-gray-600 text-sm">{image.alt}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Room Features */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
              Premium Room Features & Amenities
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Every aspect of our rooms is designed to provide comfort, convenience, and luxury 
              for our guests visiting the sacred city of Ayodhya.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {roomFeatures.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-3 flex-shrink-0"></div>
                    <p className="text-gray-700 leading-relaxed">{feature}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Hotel Highlights */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
              Why Choose Hotel Veda Inn?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Discover what makes Hotel Veda Inn the preferred choice for travelers 
              seeking comfort, convenience, and quality accommodation in Faizabad.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {hotelHighlights.map((highlight, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-gray-800 mb-3">{highlight.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{highlight.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Virtual Tour */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Experience Hotel Veda Inn Before Your Visit
            </h2>
            <p className="text-lg mb-8 leading-relaxed">
              Our gallery showcases the quality and attention to detail that defines Hotel Veda Inn. 
              From elegantly appointed rooms to modern bathrooms and convenient facilities, 
              every space is designed to enhance your stay in Faizabad while you explore the 
              spiritual treasures of nearby Ayodhya.
            </p>
            <p className="text-lg mb-8 leading-relaxed">
              Whether you're traveling for pilgrimage, business, or leisure, Hotel Veda Inn provides 
              the perfect blend of comfort, convenience, and hospitality. Our modern amenities and 
              traditional service ensure that your stay is both comfortable and memorable.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary" className="bg-white text-primary hover:bg-gray-100">
                Book Your Stay Now
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                Contact Us: +91 77558 85539
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Room Types Quick View */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
              Choose Your Accommodation
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Select from our range of carefully designed rooms and suites, 
              each offering distinct features for different needs and preferences.
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <img
                  src="/lovable-uploads/e5227926-ea9d-4dd8-b2b8-3ad3d3ac27b0.png"
                  alt="Super Deluxe Room"
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-primary text-white px-3 py-1 rounded-full text-sm font-semibold">
                    Most Popular
                  </span>
                </div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-2">Super Deluxe Rooms</h3>
                <p className="text-gray-600 mb-4">
                  Elegantly designed rooms perfect for couples and business travelers, 
                  featuring king-size beds and modern amenities.
                </p>
                <Button className="w-full bg-primary hover:bg-primary/90">
                  View Room Details
                </Button>
              </CardContent>
            </Card>

            <Card className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <img
                  src="/lovable-uploads/f418b3df-aa03-4895-93cd-7881ff4ebcd6.png"
                  alt="Family Suite"
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-orange-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                    Family Choice
                  </span>
                </div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-2">Family Suites</h3>
                <p className="text-gray-600 mb-4">
                  Spacious suites designed for families visiting Ayodhya, 
                  offering multiple beds and separate living areas.
                </p>
                <Button className="w-full bg-orange-600 hover:bg-orange-700">
                  View Suite Details
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Gallery;
