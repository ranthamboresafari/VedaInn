
import React from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Clock, CreditCard, Users, AlertCircle, FileText } from 'lucide-react';

const Terms = () => {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-primary to-primary/80">
        <div className="container mx-auto px-4 pt-16">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Terms & Conditions</h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-8">
              Hotel Veda Inn Booking Terms and Conditions
            </p>
            <p className="text-lg max-w-4xl mx-auto">
              Please read these terms and conditions carefully before making a reservation at Hotel Veda Inn. 
              By booking a room with us, you agree to be bound by these terms and conditions.
            </p>
          </div>
        </div>
      </section>

      {/* Terms Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto space-y-8">
            
            {/* Booking Terms */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="h-6 w-6 text-primary" />
                  <span>Booking Terms</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600 leading-relaxed">
                  All bookings are subject to availability and confirmation. Hotel Veda Inn reserves the right to 
                  refuse any booking at its sole discretion. Room rates are subject to change without notice 
                  until the booking is confirmed.
                </p>
                <ul className="list-disc list-inside space-y-2 text-gray-600">
                  <li>All rates are quoted per room per night unless otherwise specified</li>
                  <li>Maximum occupancy limits apply to all room types</li>
                  <li>Additional charges may apply for extra guests</li>
                  <li>All bookings must be guaranteed with a valid payment method</li>
                </ul>
              </CardContent>
            </Card>

            {/* Check-in/Check-out */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Clock className="h-6 w-6 text-primary" />
                  <span>Check-in & Check-out Policy</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Standard Check-in Time</h4>
                    <p className="text-gray-600">12:00 PM (Noon)</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Standard Check-out Time</h4>
                    <p className="text-gray-600">11:00 AM</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold text-gray-800">Early Check-in Policy</h4>
                    <p className="text-gray-600">
                      Early check-in only after 10:00 AM is possible but can be confirmed, subject to availability 
                      upon arrival at the hotel and not in advance. For check-in prior to 10:00 AM, an extra 
                      half day's tariff shall be applicable.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">Late Check-out Policy</h4>
                    <p className="text-gray-600">
                      Late check-out between 11:00 AM and 1:00 PM is possible (free of charge) but can be confirmed, 
                      subject to availability, only at the time of check-out and not in advance. For check-out 
                      after 2:00 PM, an extra night's tariff shall be applicable.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Payment Terms */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CreditCard className="h-6 w-6 text-primary" />
                  <span>Payment Terms</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600 leading-relaxed">
                  The full booking amount needs to be paid at the time of check-in. If part-payment was made 
                  for the booking, the remainder of the booking amount is what needs to be paid at the time of check-in.
                </p>
                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold text-gray-800">Accepted Payment Methods</h4>
                    <ul className="list-disc list-inside space-y-1 text-gray-600">
                      <li>All major credit cards (Visa, MasterCard, American Express)</li>
                      <li>Debit cards</li>
                      <li>UPI payments</li>
                      <li>Cash payments</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">GST Details</h4>
                    <p className="text-gray-600">
                      Addition of GST details or any kind of modification on the invoice cannot be made post 
                      check-out. Hence, please add all the required details with accuracy while making the booking itself.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Identification Requirements */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="h-6 w-6 text-primary" />
                  <span>Identification Requirements</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600 leading-relaxed">
                  All adults must carry one of these photo ID cards at the time of check-in:
                </p>
                <ul className="list-disc list-inside space-y-1 text-gray-600">
                  <li>Driving License</li>
                  <li>Voters Card</li>
                  <li>Passport</li>
                  <li>Ration Card</li>
                  <li>Aadhar Card</li>
                </ul>
                <p className="text-red-600 font-medium">
                  Note: PAN Cards are not accepted as valid identification.
                </p>
              </CardContent>
            </Card>

            {/* Child Policy */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="h-6 w-6 text-primary" />
                  <span>Child Reservation Policy</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600 leading-relaxed">
                  A maximum of 1 child up to an age of 6 years and an extra infant up to an age of 2 years 
                  is allowed free of charge, subject to room occupancy capacity.
                </p>
                <ul className="list-disc list-inside space-y-1 text-gray-600">
                  <li>Breakfast will be included in stay as per plans selected</li>
                  <li>No extra bed or mattress will be provided for free children</li>
                  <li>Extra person charges are applicable for anyone above 7 years of age</li>
                  <li>Extra person charges are also applicable for extra kids during check-in</li>
                </ul>
              </CardContent>
            </Card>

            {/* Guest Policies */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertCircle className="h-6 w-6 text-primary" />
                  <span>Guest Policies</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-gray-800">Couple Friendly Policy</h4>
                    <p className="text-gray-600">Hotel Veda Inn welcomes unmarried couples.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">Local ID Policy</h4>
                    <p className="text-gray-600">
                      Guests can check in using any local or outstation ID proof (PAN card not accepted).
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">Flexible Check-in and Check-out</h4>
                    <p className="text-gray-600">
                      Allows guests to extend their check-in or check-out by a few hours on the same day, 
                      subject to availability.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* COVID-19 Guidelines */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="h-6 w-6 text-primary" />
                  <span>COVID-19 Guidelines</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 leading-relaxed">
                  Due to COVID-19 outbreak, we urge you to stay tuned to latest updates by Local and Central 
                  Government with respect to COVID tests, lockdowns, and travel restrictions before confirming 
                  your Hotel Booking. The hotel follows all safety protocols as mandated by the government.
                </p>
              </CardContent>
            </Card>

            {/* Liability */}
            <Card>
              <CardHeader>
                <CardTitle>Hotel Liability</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600 leading-relaxed">
                  Hotel Veda Inn shall not be liable for any loss, damage, or injury to guests or their belongings 
                  except in cases of proven negligence on the part of the hotel.
                </p>
                <ul className="list-disc list-inside space-y-1 text-gray-600">
                  <li>Guests are responsible for their personal belongings</li>
                  <li>The hotel provides safe deposit facilities for valuables</li>
                  <li>Any damage to hotel property will be charged to the guest</li>
                  <li>The hotel reserves the right to remove disruptive guests</li>
                </ul>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <Card className="bg-primary/5">
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  For any questions regarding these terms and conditions, please contact us:
                </p>
                <div className="space-y-2 text-gray-600">
                  <p><strong>Phone:</strong> +91 77558 85539</p>
                  <p><strong>Email:</strong> info@hotelvedainn.com</p>
                  <p><strong>Address:</strong> Fatehganj Devkali Rd, Deokali, Faizabad, Uttar Pradesh 224001</p>
                </div>
              </CardContent>
            </Card>

          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Terms;
