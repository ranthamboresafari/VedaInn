
import React from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar, Clock, CreditCard, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

const Cancellation = () => {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-primary to-primary/80">
        <div className="container mx-auto px-4 pt-16">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Cancellation Policy</h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-8">
              Hotel Veda Inn Booking Cancellation & Refund Policy
            </p>
            <p className="text-lg max-w-4xl mx-auto">
              Please review our cancellation policy carefully before making your reservation. 
              This policy outlines the terms and conditions for cancelling bookings and refund eligibility.
            </p>
          </div>
        </div>
      </section>

      {/* Policy Overview */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            
            {/* Quick Reference */}
            <Card className="mb-8">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="h-6 w-6 text-primary" />
                  <span>Cancellation Policy Quick Reference</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="text-center p-4 bg-green-50 rounded-lg border border-green-200">
                    <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-3" />
                    <h3 className="font-semibold text-green-800 mb-2">15+ Days Before</h3>
                    <p className="text-green-700">100% Refund</p>
                    <p className="text-sm text-green-600 mt-1">Full refund of total amount</p>
                  </div>
                  <div className="text-center p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                    <AlertTriangle className="h-12 w-12 text-yellow-600 mx-auto mb-3" />
                    <h3 className="font-semibold text-yellow-800 mb-2">7-15 Days Before</h3>
                    <p className="text-yellow-700">50% Refund</p>
                    <p className="text-sm text-yellow-600 mt-1">50% refund of total amount</p>
                  </div>
                  <div className="text-center p-4 bg-red-50 rounded-lg border border-red-200">
                    <XCircle className="h-12 w-12 text-red-600 mx-auto mb-3" />
                    <h3 className="font-semibold text-red-800 mb-2">Within 7 Days</h3>
                    <p className="text-red-700">No Refund</p>
                    <p className="text-sm text-red-600 mt-1">No refund applicable</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-8">
              
              {/* Detailed Policy */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Clock className="h-6 w-6 text-primary" />
                    <span>Detailed Cancellation Terms</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  
                  <div className="border-l-4 border-green-500 pl-4">
                    <h4 className="font-semibold text-gray-800 mb-2">Cancellation 15+ Days Before Check-in</h4>
                    <p className="text-gray-600 leading-relaxed">
                      If you cancel your reservation 15 days or more before your scheduled check-in date, 
                      you will receive a <strong>100% full refund</strong> of the total booking amount. 
                      The refund will be processed within 5-7 business days to your original payment method.
                    </p>
                  </div>

                  <div className="border-l-4 border-yellow-500 pl-4">
                    <h4 className="font-semibold text-gray-800 mb-2">Cancellation 7-15 Days Before Check-in</h4>
                    <p className="text-gray-600 leading-relaxed">
                      If you cancel your reservation between 7-15 days before your scheduled check-in date, 
                      you will receive a <strong>50% refund</strong> of the total booking amount. 
                      The remaining 50% will be retained as a cancellation fee.
                    </p>
                  </div>

                  <div className="border-l-4 border-red-500 pl-4">
                    <h4 className="font-semibold text-gray-800 mb-2">Cancellation Within 7 Days of Check-in</h4>
                    <p className="text-gray-600 leading-relaxed">
                      If you cancel your reservation within 7 days of your scheduled check-in date, 
                      <strong>no refund will be provided</strong>. The full booking amount will be retained 
                      as a cancellation fee.
                    </p>
                  </div>

                </CardContent>
              </Card>

              {/* Alternative Policy (Legacy) */}
              <Card>
                <CardHeader>
                  <CardTitle>Alternative Cancellation Policy</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    For certain booking channels and promotional rates, the following policy may apply:
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-1 flex-shrink-0" />
                      <div>
                        <p className="text-gray-700">
                          <strong>5+ Days Before Check-in:</strong> No cancellation fee is charged if the booking 
                          is cancelled 5 days prior to the standard check-in time.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <XCircle className="h-5 w-5 text-red-600 mt-1 flex-shrink-0" />
                      <div>
                        <p className="text-gray-700">
                          <strong>Within 5 Days:</strong> If the booking is cancelled within 5 days of the standard 
                          check-in time, one night's tariff shall be charged for the room(s) booked.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* No-Show Policy */}
              <Card>
                <CardHeader>
                  <CardTitle>No-Show Policy</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    If you fail to check-in on your scheduled arrival date without prior cancellation 
                    (no-show), the following charges apply:
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li>Full booking amount will be forfeited</li>
                    <li>No refund will be provided</li>
                    <li>Remaining nights of the reservation will be automatically cancelled</li>
                  </ul>
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mt-4">
                    <p className="text-yellow-800 text-sm">
                      <strong>Important:</strong> Please contact us if you expect to arrive late or need to 
                      modify your check-in time to avoid no-show charges.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Non-Refundable Bookings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <AlertTriangle className="h-6 w-6 text-primary" />
                    <span>Non-Refundable Bookings</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    Some promotional rates and special offers may be designated as non-refundable:
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li>These bookings cannot be cancelled for a refund under any circumstances</li>
                    <li>Changes to non-refundable bookings may not be permitted</li>
                    <li>Non-refundable status will be clearly indicated during the booking process</li>
                  </ul>
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <p className="text-red-800 text-sm">
                      <strong>Note:</strong> Please note that refunds shall not be applicable for 
                      non-refundable bookings. Please also have a look at the cancellation policy 
                      while booking rooms on mentioned/selected dates.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Refund Process */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <CreditCard className="h-6 w-6 text-primary" />
                    <span>Refund Process</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-2">How to Cancel</h4>
                      <p className="text-gray-600 mb-2">
                        To cancel your reservation, please contact us through any of the following methods:
                      </p>
                      <ul className="list-disc list-inside space-y-1 text-gray-600">
                        <li>Phone: +91 77558 85539</li>
                        <li>Email: info@hotelvedainn.com</li>
                        <li>WhatsApp: +91 77558 85539</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-2">Refund Timeline</h4>
                      <ul className="list-disc list-inside space-y-1 text-gray-600">
                        <li>Credit/Debit Card: 5-7 business days</li>
                        <li>UPI/Bank Transfer: 3-5 business days</li>
                        <li>Cash payments: Immediate upon cancellation confirmation</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-2">Required Information</h4>
                      <p className="text-gray-600">
                        When requesting a cancellation, please provide your booking reference number, 
                        guest name, and check-in date for quick processing.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Special Circumstances */}
              <Card>
                <CardHeader>
                  <CardTitle>Special Circumstances</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    In case of unforeseen circumstances, Hotel Veda Inn may consider exceptions to the 
                    standard cancellation policy on a case-by-case basis:
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li>Medical emergencies (with valid documentation)</li>
                    <li>Natural disasters or government-imposed travel restrictions</li>
                    <li>Flight cancellations by airlines (with proof)</li>
                    <li>Other extraordinary circumstances beyond guest control</li>
                  </ul>
                  <p className="text-sm text-gray-500 mt-4">
                    Such exceptions are at the sole discretion of hotel management and require proper documentation.
                  </p>
                </CardContent>
              </Card>

              {/* Contact Information */}
              <Card className="bg-primary/5">
                <CardHeader>
                  <CardTitle>Contact for Cancellations</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">
                    For cancellations, modifications, or questions about this policy, please contact us:
                  </p>
                  <div className="space-y-2 text-gray-600">
                    <p><strong>Phone:</strong> +91 77558 85539</p>
                    <p><strong>Email:</strong> info@hotelvedainn.com</p>
                    <p><strong>WhatsApp:</strong> +91 77558 85539</p>
                    <p><strong>Address:</strong> Fatehganj Devkali Rd, Deokali, Faizabad, Uttar Pradesh 224001</p>
                  </div>
                  <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded">
                    <p className="text-blue-800 text-sm">
                      <strong>Business Hours:</strong> Our front desk is available 24/7 for cancellations and assistance.
                    </p>
                  </div>
                </CardContent>
              </Card>

            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Cancellation;
