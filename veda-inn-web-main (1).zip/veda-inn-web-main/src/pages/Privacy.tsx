
import React from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Eye, Lock, Database, Phone, Mail } from 'lucide-react';

const Privacy = () => {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-primary to-primary/80">
        <div className="container mx-auto px-4 pt-16">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Privacy Policy</h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-8">
              Hotel Veda Inn Privacy Policy & Data Protection
            </p>
            <p className="text-lg max-w-4xl mx-auto">
              Your privacy is important to us. This policy outlines how Hotel Veda Inn collects, uses, 
              and protects your personal information when you visit our website or stay at our hotel.
            </p>
          </div>
        </div>
      </section>

      {/* Privacy Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto space-y-8">
            
            {/* Information Collection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Database className="h-6 w-6 text-primary" />
                  <span>Information We Collect</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600 leading-relaxed">
                  We collect information that you provide directly to us when you make a reservation, 
                  register for services, or contact us. This may include:
                </p>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Personal Information</h4>
                    <ul className="list-disc list-inside space-y-1 text-gray-600">
                      <li>Name and contact details</li>
                      <li>Email address and phone number</li>
                      <li>Address information</li>
                      <li>Government-issued ID details</li>
                      <li>Payment information</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Booking Information</h4>
                    <ul className="list-disc list-inside space-y-1 text-gray-600">
                      <li>Reservation details</li>
                      <li>Room preferences</li>
                      <li>Special requests</li>
                      <li>Guest history</li>
                      <li>Feedback and reviews</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* How We Use Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Eye className="h-6 w-6 text-primary" />
                  <span>How We Use Your Information</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600 leading-relaxed">
                  We use the information we collect for various purposes, including:
                </p>
                <ul className="list-disc list-inside space-y-2 text-gray-600">
                  <li>Processing and managing your reservations</li>
                  <li>Providing customer service and support</li>
                  <li>Communicating with you about your bookings</li>
                  <li>Improving our services and facilities</li>
                  <li>Ensuring security and preventing fraud</li>
                  <li>Complying with legal obligations</li>
                  <li>Marketing communications (with your consent)</li>
                </ul>
              </CardContent>
            </Card>

            {/* Data Protection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Lock className="h-6 w-6 text-primary" />
                  <span>Data Protection & Security</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600 leading-relaxed">
                  We implement appropriate technical and organizational security measures to protect 
                  your personal information against unauthorized access, alteration, disclosure, or destruction.
                </p>
                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold text-gray-800">Security Measures Include:</h4>
                    <ul className="list-disc list-inside space-y-1 text-gray-600">
                      <li>Secure data transmission and storage</li>
                      <li>Access controls and authentication</li>
                      <li>Regular security assessments</li>
                      <li>Staff training on data protection</li>
                      <li>Incident response procedures</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Information Sharing */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="h-6 w-6 text-primary" />
                  <span>Information Sharing</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600 leading-relaxed">
                  We do not sell, trade, or otherwise transfer your personal information to third parties 
                  without your consent, except in the following circumstances:
                </p>
                <ul className="list-disc list-inside space-y-2 text-gray-600">
                  <li>When required by law or legal process</li>
                  <li>To protect our rights, property, or safety</li>
                  <li>With service providers who assist in our operations</li>
                  <li>In connection with business transfers</li>
                  <li>With your explicit consent</li>
                </ul>
              </CardContent>
            </Card>

            {/* Your Rights */}
            <Card>
              <CardHeader>
                <CardTitle>Your Rights & Choices</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600 leading-relaxed">
                  You have certain rights regarding your personal information:
                </p>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Access & Correction</h4>
                    <ul className="list-disc list-inside space-y-1 text-gray-600">
                      <li>Request access to your data</li>
                      <li>Correct inaccurate information</li>
                      <li>Update your preferences</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Control & Deletion</h4>
                    <ul className="list-disc list-inside space-y-1 text-gray-600">
                      <li>Opt-out of marketing communications</li>
                      <li>Request data deletion</li>
                      <li>Withdraw consent</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Cookies */}
            <Card>
              <CardHeader>
                <CardTitle>Cookies & Tracking Technologies</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600 leading-relaxed">
                  Our website may use cookies and similar tracking technologies to enhance your browsing 
                  experience and analyze website usage.
                </p>
                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold text-gray-800">Types of Cookies We Use:</h4>
                    <ul className="list-disc list-inside space-y-1 text-gray-600">
                      <li>Essential cookies for website functionality</li>
                      <li>Analytics cookies to understand usage patterns</li>
                      <li>Preference cookies to remember your settings</li>
                      <li>Marketing cookies (with your consent)</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Data Retention */}
            <Card>
              <CardHeader>
                <CardTitle>Data Retention</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600 leading-relaxed">
                  We retain your personal information only for as long as necessary to fulfill the purposes 
                  for which it was collected, comply with legal obligations, and resolve disputes.
                </p>
                <ul className="list-disc list-inside space-y-1 text-gray-600">
                  <li>Booking records: Retained for accounting and legal compliance</li>
                  <li>Marketing preferences: Until you unsubscribe</li>
                  <li>CCTV footage: Retained for security purposes as per regulations</li>
                  <li>Payment information: Processed securely and not stored</li>
                </ul>
              </CardContent>
            </Card>

            {/* Updates to Policy */}
            <Card>
              <CardHeader>
                <CardTitle>Updates to This Policy</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 leading-relaxed">
                  We may update this privacy policy from time to time to reflect changes in our practices 
                  or applicable laws. We will notify you of any material changes by posting the updated 
                  policy on our website with the effective date.
                </p>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <Card className="bg-primary/5">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Phone className="h-6 w-6 text-primary" />
                  <span>Contact Us</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  If you have any questions about this privacy policy or our data practices, please contact us:
                </p>
                <div className="space-y-2 text-gray-600">
                  <p><strong>Phone:</strong> +91 77558 85539</p>
                  <p><strong>Email:</strong> info@hotelvedainn.com</p>
                  <p><strong>Address:</strong> Fatehganj Devkali Rd, Deokali, Faizabad, Uttar Pradesh 224001</p>
                </div>
                <p className="text-sm text-gray-500 mt-4">
                  Last updated: January 2024
                </p>
              </CardContent>
            </Card>

          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Privacy;
