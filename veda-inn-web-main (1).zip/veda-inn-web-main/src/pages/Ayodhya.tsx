import React from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MapPin, Clock, Camera, Heart, Star, Users } from 'lucide-react';

const Ayodhya = () => {
  const attractions = [
    {
      name: 'Ram Mandir (Ram Temple)',
      description: 'The magnificent Ram Mandir is the crown jewel of Ayodhya, dedicated to Lord Rama. This architectural marvel represents centuries of devotion and faith.',
      distance: '15 minutes from Hotel Veda Inn',
      timing: '6:00 AM - 10:00 PM',
      highlights: ['Sacred birthplace of Lord Rama', 'Stunning architecture', 'Spiritual significance'],
      image: 'https://images.unsplash.com/photo-1609920658906-8223bd289001'
    },
    {
      name: 'Hanuman Garhi',
      description: 'A fortress-like temple dedicated to Lord Hanuman, offering panoramic views of Ayodhya. This hilltop shrine is one of the most visited temples in the city.',
      distance: '20 minutes from Hotel Veda Inn',
      timing: '5:00 AM - 10:00 PM',
      highlights: ['Hilltop temple', 'City views', 'Hanuman devotion'],
      image: 'https://images.unsplash.com/photo-1466442929976-97f336a657be'
    },
    {
      name: 'Kanak Bhawan',
      description: 'Also known as Sone-ka-Ghar, this beautiful temple is dedicated to Rama and Sita. The temple is famous for its golden idols and intricate artwork.',
      distance: '18 minutes from Hotel Veda Inn',
      timing: '6:00 AM - 12:00 PM, 4:00 PM - 9:00 PM',
      highlights: ['Golden idols', 'Artistic architecture', 'Rama-Sita temple'],
      image: 'https://images.unsplash.com/photo-1492321936769-b49830bc1d1e'
    },
    {
      name: 'Saryu River Ghats',
      description: 'The sacred Saryu River ghats are perfect for evening aarti and peaceful boat rides. Experience the spiritual ambiance of this holy river.',
      distance: '20 minutes from Hotel Veda Inn',
      timing: 'All day (Aarti: 6:00 PM)',
      highlights: ['River aarti', 'Boat rides', 'Peaceful atmosphere'],
      image: 'https://images.unsplash.com/photo-1473177104440-ffee2f376098'
    },
    {
      name: 'Ramkot',
      description: 'The main place of worship believed to be the original location of Lord Rama\'s palace. This area holds immense historical and religious significance.',
      distance: '16 minutes from Hotel Veda Inn',
      timing: '6:00 AM - 8:00 PM',
      highlights: ['Historical significance', 'Palace ruins', 'Archaeological site'],
      image: 'https://images.unsplash.com/photo-1460574283810-2aab119d8511'
    },
    {
      name: 'Treta Ke Thakur',
      description: 'An ancient temple complex where Lord Rama performed the Ashvamedha Yajna. The temple showcases beautiful sculptures and religious art.',
      distance: '22 minutes from Hotel Veda Inn',
      timing: '6:00 AM - 9:00 PM',
      highlights: ['Ancient temple', 'Historical yajna site', 'Religious sculptures'],
      image: 'https://images.unsplash.com/photo-1587474260584-136574528ed5'
    }
  ];

  const pilgrimageGuide = [
    {
      title: 'Best Time to Visit',
      content: 'October to March offers pleasant weather for exploring Ayodhya. Avoid summer months (April-June) due to extreme heat.'
    },
    {
      title: 'What to Wear',
      content: 'Modest clothing is recommended. Comfortable walking shoes are essential as you\'ll be walking on temple grounds.'
    },
    {
      title: 'Photography',
      content: 'Photography rules vary by temple. Always ask permission before taking photos inside temple premises.'
    },
    {
      title: 'Local Transport',
      content: 'Auto-rickshaws, cycle-rickshaws, and taxis are readily available. Hotel Veda Inn provides cab services for convenient temple visits.'
    }
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-orange-600 to-red-600">
        <div className="container mx-auto px-4 pt-16">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">Discover Sacred Ayodhya</h1>
            <p className="text-xl md:text-2xl max-w-4xl mx-auto mb-8">
              The Holy Birthplace of Lord Rama - Experience Divine Spirituality and Ancient Heritage
            </p>
            <p className="text-lg max-w-5xl mx-auto leading-relaxed">
              Ayodhya, located just minutes from Hotel Veda Inn in Faizabad, is one of India's most sacred cities and the legendary birthplace of Lord Rama. 
              This ancient city, mentioned in the great epic Ramayana, attracts millions of devotees and tourists from around the world who come to experience 
              its divine atmosphere, magnificent temples, and rich cultural heritage that spans thousands of years.
            </p>
          </div>
        </div>
      </section>

      {/* About Ayodhya */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
                The Sacred City of Ayodhya - A Spiritual Journey Through Time
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Ayodhya, meaning "unconquerable" in Sanskrit, is an ancient city in Uttar Pradesh that holds immense religious and historical significance in Hindu tradition. 
                According to Hindu scriptures, Ayodhya was the capital of the ancient Kingdom of Kosala and the birthplace of Lord Rama, the seventh avatar of Lord Vishnu. 
                The city is mentioned extensively in the Ramayana, one of the two major Sanskrit epics of ancient India.
              </p>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Today, Ayodhya stands as a testament to India's rich spiritual heritage, featuring magnificent temples, sacred ghats along the Saryu River, 
                and countless sites associated with the life of Lord Rama. The recent construction of the grand Ram Mandir has further elevated the city's 
                status as a premier pilgrimage destination, attracting devotees from across the globe.
              </p>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                Staying at Hotel Veda Inn in nearby Faizabad provides the perfect base for exploring Ayodhya's spiritual treasures. Our hotel offers 
                comfortable accommodation with easy access to all major temples and attractions, ensuring your pilgrimage is both meaningful and comfortable.
              </p>
              <Button size="lg" className="bg-orange-600 hover:bg-orange-700">
                Plan Your Pilgrimage
              </Button>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1609920658906-8223bd289001"
                alt="Ayodhya Ram Mandir Temple Complex"
                className="w-full h-[500px] object-cover rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Major Attractions */}
      <section className="py-16 bg-orange-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
              Sacred Temples and Attractions in Ayodhya
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Explore the divine temples and sacred sites that make Ayodhya one of India's most revered pilgrimage destinations. 
              Each location offers a unique spiritual experience and glimpse into ancient Hindu traditions.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {attractions.map((attraction, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow overflow-hidden group">
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={attraction.image}
                    alt={attraction.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                </div>
                <CardHeader>
                  <CardTitle className="text-xl text-orange-800">{attraction.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4 leading-relaxed">{attraction.description}</p>
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-sm text-gray-500">
                      <MapPin className="h-4 w-4 mr-2" />
                      {attraction.distance}
                    </div>
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="h-4 w-4 mr-2" />
                      {attraction.timing}
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Highlights:</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      {attraction.highlights.map((highlight, i) => (
                        <li key={i}>• {highlight}</li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pilgrimage Guide */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
              Your Complete Ayodhya Pilgrimage Guide
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Make the most of your spiritual journey to Ayodhya with our comprehensive guide covering everything you need to know 
              for a meaningful and comfortable pilgrimage experience.
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {pilgrimageGuide.map((guide, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-xl text-orange-800">{guide.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">{guide.content}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Stay at Hotel Veda Inn */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
              Why Choose Hotel Veda Inn for Your Ayodhya Pilgrimage?
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Hotel Veda Inn in Faizabad offers the perfect combination of comfort, convenience, and spiritual ambiance 
              for your Ayodhya pilgrimage journey.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <MapPin className="h-12 w-12 text-orange-600 mx-auto mb-4" />
                <CardTitle className="text-xl">Strategic Location</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Located in Faizabad, just 15 minutes from major Ayodhya temples. Easy access to Ram Mandir, 
                  Hanuman Garhi, and other sacred sites.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Users className="h-12 w-12 text-orange-600 mx-auto mb-4" />
                <CardTitle className="text-xl">Pilgrimage Services</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Dedicated travel desk for temple visits, cab services, and local guidance. 
                  Our team understands pilgrims' needs and provides personalized assistance.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Heart className="h-12 w-12 text-orange-600 mx-auto mb-4" />
                <CardTitle className="text-xl">Comfort & Peace</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Clean, comfortable rooms with modern amenities. Peaceful environment perfect for 
                  spiritual reflection and rest after temple visits.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Historical Significance */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
              The Historical and Cultural Legacy of Ayodhya
            </h2>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              Ayodhya's history spans over several millennia, with archaeological evidence suggesting human habitation dating back to 
              the 8th century BCE. The city has been mentioned in various ancient texts including the Ramayana, Mahabharata, and 
              several Puranas, establishing its significance in Hindu tradition and Indian culture.
            </p>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              The city served as the capital of the ancient Kingdom of Kosala, ruled by the Ikshvaku dynasty, to which Lord Rama belonged. 
              Throughout history, Ayodhya has been a center of learning, culture, and spirituality, attracting scholars, pilgrims, and 
              devotees from across the Indian subcontinent and beyond.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Today, Ayodhya continues to be a living testament to India's rich spiritual heritage. The city seamlessly blends ancient 
              traditions with modern facilities, ensuring that pilgrims can experience the divine atmosphere while enjoying contemporary 
              comforts. Hotel Veda Inn serves as your gateway to this sacred city, providing excellent accommodation and services 
              for an unforgettable spiritual journey.
            </p>
            <a
              href="https://wa.me/917755885539"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-3 rounded-lg font-medium transition-all duration-300 hover:shadow-lg transform hover:scale-105 inline-block"
            >
              Book Your Stay at Hotel Veda Inn
            </a>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Ayodhya;
