
import React from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Utensils, 
  Coffee, 
  Clock, 
  Users, 
  Star, 
  Heart,
  Sunrise,
  Sun,
  Sunset,
  Moon
} from 'lucide-react';

const Dining = () => {
  const diningOptions = [
    {
      name: 'Rooftop Restaurant',
      icon: Utensils,
      description: 'Experience fine dining under the stars at our rooftop restaurant with panoramic views of Faizabad and distant glimpses of Ayodhya.',
      cuisine: 'Multi-cuisine including North Indian, South Indian, Chinese, and Continental',
      timings: '7:00 AM - 11:00 PM',
      speciality: 'Rooftop dining with city views',
      highlights: ['Panoramic city views', 'Al fresco dining', 'Romantic ambiance', 'Live cooking stations']
    },
    {
      name: 'Main Restaurant',
      icon: Coffee,
      description: 'Our main restaurant offers a comfortable dining experience with a variety of regional and international cuisines in an elegant setting.',
      cuisine: 'Indian, Continental, Chinese, and Local Awadhi specialties',
      timings: '6:00 AM - 11:00 PM',
      speciality: 'Traditional Awadhi cuisine',
      highlights: ['Air-conditioned comfort', 'Family-friendly', 'Buffet options', 'A-la-carte menu']
    },
    {
      name: 'Roof-Top Café',
      icon: Coffee,
      description: 'Casual dining and refreshments in our rooftop café, perfect for light meals, snacks, and beverages throughout the day.',
      cuisine: 'Snacks, Beverages, Light meals, and Desserts',
      timings: '10:00 AM - 10:00 PM',
      speciality: 'Quick bites and refreshments',
      highlights: ['Casual atmosphere', 'Quick service', 'Fresh beverages', 'Light snacks']
    }
  ];

  const mealTimings = [
    {
      icon: Sunrise,
      meal: 'Breakfast',
      time: '7:00 AM - 10:30 AM',
      description: 'Start your day with our complimentary breakfast featuring traditional Indian dishes, continental options, fresh fruits, and beverages.',
      menu: ['Traditional South Indian breakfast', 'North Indian parathas and sabzi', 'Continental bread and cereals', 'Fresh seasonal fruits', 'Tea, coffee, and fresh juices']
    },
    {
      icon: Sun,
      meal: 'Lunch',
      time: '12:00 PM - 3:30 PM',
      description: 'Enjoy a hearty lunch with regional specialties and popular dishes from across India, perfect after your temple visits.',
      menu: ['Dal and rice combinations', 'Regional vegetarian thalis', 'North Indian curries', 'Fresh rotis and naan', 'Seasonal vegetable preparations']
    },
    {
      icon: Sunset,
      meal: 'Dinner',
      time: '7:00 PM - 10:30 PM',
      description: 'Conclude your day with our elaborate dinner featuring authentic Awadhi cuisine and contemporary dishes in a serene ambiance.',
      menu: ['Awadhi biryanis and pulavs', 'Vegetarian and non-vegetarian curries', 'Traditional sweets and desserts', 'Continental options', 'Special pilgrimage thalis']
    },
    {
      icon: Moon,
      meal: 'Late Night Snacks',
      time: '10:30 PM - 12:00 AM',
      description: 'Light refreshments and snacks available for late arrivals and night owls, served through our room service.',
      menu: ['Light snacks and sandwiches', 'Hot beverages', 'Instant noodles', 'Fresh fruits', 'Room service available']
    }
  ];

  const specialFeatures = [
    {
      icon: Heart,
      title: 'Vegetarian Friendly',
      description: 'Pure vegetarian options available with dedicated cooking areas, perfect for pilgrims visiting Ayodhya.'
    },
    {
      icon: Star,
      title: 'Local Specialties',
      description: 'Authentic Awadhi and Faizabad regional dishes prepared by expert local chefs using traditional recipes.'
    },
    {
      icon: Users,
      title: 'Group Dining',
      description: 'Special arrangements for group dining and pilgrimage parties with customized menu options.'
    },
    {
      icon: Clock,
      title: '24/7 Room Service',
      description: 'Round-the-clock room service for your convenience, ensuring you never go hungry during your stay.'
    }
  ];

  const events = [
    {
      title: 'Kitty Party Arrangements',
      description: 'Host your social gatherings and kitty parties in our elegant dining spaces with special menu arrangements and decorations.',
      features: ['Customized menu planning', 'Decoration services', 'Private dining areas', 'Group entertainment options']
    },
    {
      title: 'Family Celebrations',
      description: 'Celebrate special occasions with your family in our warm and welcoming restaurant environment.',
      features: ['Birthday celebrations', 'Anniversary dinners', 'Religious ceremonies', 'Family reunion meals']
    },
    {
      title: 'Corporate Events',
      description: 'Professional dining solutions for business meetings, conferences, and corporate gatherings.',
      features: ['Business lunch arrangements', 'Conference catering', 'Meeting room dining', 'Corporate packages']
    }
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-orange-600 to-red-600">
        <div className="container mx-auto px-4 pt-16">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Exquisite Dining at Hotel Veda Inn
            </h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-8">
              Savor Authentic Flavors and Multi-Cuisine Delights in Faizabad
            </p>
            <p className="text-lg max-w-4xl mx-auto leading-relaxed">
              Experience culinary excellence at Hotel Veda Inn with our diverse dining options featuring traditional Awadhi cuisine, 
              contemporary dishes, and international flavors. Our rooftop restaurant offers spectacular views while our main restaurant 
              provides comfortable family dining. Perfect for pilgrims, families, and business travelers visiting the sacred city of Ayodhya.
            </p>
          </div>
        </div>
      </section>

      {/* Dining Options */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
              Our Dining Venues
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Choose from our variety of dining spaces, each offering a unique ambiance and culinary experience 
              tailored to different preferences and occasions.
            </p>
          </div>
          <div className="space-y-8">
            {diningOptions.map((option, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="grid lg:grid-cols-3 gap-0">
                  <div className="lg:col-span-2 p-8">
                    <div className="flex items-center space-x-3 mb-4">
                      <option.icon className="h-8 w-8 text-orange-600" />
                      <h3 className="text-2xl font-bold text-gray-800">{option.name}</h3>
                    </div>
                    <p className="text-gray-600 mb-4 leading-relaxed">{option.description}</p>
                    <div className="grid md:grid-cols-2 gap-4 mb-6">
                      <div>
                        <h4 className="font-semibold text-gray-800 mb-2">Cuisine Types:</h4>
                        <p className="text-gray-600 text-sm">{option.cuisine}</p>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800 mb-2">Operating Hours:</h4>
                        <p className="text-gray-600 text-sm">{option.timings}</p>
                      </div>
                    </div>
                    <div className="mb-6">
                      <h4 className="font-semibold text-gray-800 mb-2">Highlights:</h4>
                      <div className="flex flex-wrap gap-2">
                        {option.highlights.map((highlight, i) => (
                          <span key={i} className="bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-sm">
                            {highlight}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="bg-gradient-to-br from-orange-100 to-orange-200 p-8 flex items-center justify-center">
                    <div className="text-center">
                      <option.icon className="h-16 w-16 text-orange-600 mx-auto mb-4" />
                      <h4 className="text-lg font-semibold text-orange-800 mb-2">Specialty</h4>
                      <p className="text-orange-700">{option.speciality}</p>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Meal Timings */}
      <section className="py-16 bg-orange-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
              Daily Meal Timings & Menus
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Plan your day with our comprehensive dining schedule featuring diverse menu options 
              from traditional breakfast to late-night snacks.
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            {mealTimings.map((meal, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <meal.icon className="h-8 w-8 text-orange-600" />
                    <div>
                      <CardTitle className="text-xl text-gray-800">{meal.meal}</CardTitle>
                      <p className="text-orange-600 font-semibold">{meal.time}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4 leading-relaxed">{meal.description}</p>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Menu Highlights:</h4>
                    <ul className="text-gray-600 text-sm space-y-1">
                      {meal.menu.map((item, i) => (
                        <li key={i}>• {item}</li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Special Features */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
              Special Dining Features
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Discover the unique features that make dining at Hotel Veda Inn a memorable experience 
              for pilgrims and travelers visiting Ayodhya.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {specialFeatures.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <feature.icon className="h-12 w-12 text-orange-600 mx-auto mb-4" />
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Events & Celebrations */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
              Events & Celebrations
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Host your special occasions and celebrations in our elegant dining spaces with 
              customized arrangements and personalized service.
            </p>
          </div>
          <div className="grid lg:grid-cols-3 gap-8">
            {events.map((event, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-xl text-orange-800">{event.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4 leading-relaxed">{event.description}</p>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Features Include:</h4>
                    <ul className="text-gray-600 text-sm space-y-1">
                      {event.features.map((feature, i) => (
                        <li key={i}>• {feature}</li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Local Cuisine Focus */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
                Authentic Awadhi & Local Cuisine
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Experience the rich culinary heritage of Awadh and Faizabad with our authentic local dishes 
                prepared using traditional recipes and cooking methods. Our expert chefs bring generations 
                of culinary expertise to create flavors that reflect the cultural richness of this historic region.
              </p>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                From aromatic biryanis and kebabs to traditional sweets and regional specialties, 
                our menu celebrates the diverse flavors of Uttar Pradesh. Perfect for pilgrims wanting 
                to experience local culture through cuisine while maintaining high standards of hygiene and quality.
              </p>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                We also offer pure vegetarian options prepared in dedicated areas, ensuring that 
                your dietary preferences and religious requirements are respected throughout your 
                spiritual journey to Ayodhya.
              </p>
              <Button size="lg" className="bg-orange-600 hover:bg-orange-700">
                View Full Menu
              </Button>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1546833999-b9f581a1996d"
                alt="Traditional Awadhi Cuisine at Hotel Veda Inn"
                className="w-full h-[400px] object-cover rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Booking CTA */}
      <section className="py-16 bg-orange-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
              Reserve Your Dining Experience
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Book your table at Hotel Veda Inn and enjoy exceptional dining experiences during your 
              stay in Faizabad. Whether you're planning a family meal, romantic dinner, or group celebration, 
              our team is ready to make your dining experience memorable.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-orange-600 hover:bg-orange-700">
                Reserve Table
              </Button>
              <Button size="lg" variant="outline">
                Call +91 77558 85539
              </Button>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Dining;
