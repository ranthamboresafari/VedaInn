
import React from 'react';
import Layout from '@/components/Layout';
import HeroSection from '@/components/HeroSection';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Wifi, 
  Shield, 
  Car, 
  Utensils, 
  Coffee, 
  Tv, 
  Bed, 
  Bath,
  Star,
  MapPin,
  Users,
  Building,
  Headphones
} from 'lucide-react';

const Index = () => {
  const facilities = [
    { icon: Wifi, title: 'Free WiFi', description: 'High-speed internet throughout the hotel' },
    { icon: Shield, title: '24 Hour Security', description: 'Round-the-clock security for your safety' },
    { icon: Car, title: 'Free Parking', description: 'Complimentary parking for all guests' },
    { icon: Utensils, title: 'Restaurant', description: 'Multi-cuisine dining with rooftop seating' },
    { icon: Building, title: 'Elevator', description: 'Easy access to all floors' },
    { icon: Headphones, title: '24 Hour Concierge', description: 'Personalized assistance and local guidance' }
  ];

  const roomFeatures = [
    { icon: Tv, title: 'Flat Screen TV', description: 'Entertainment at your fingertips' },
    { icon: Coffee, title: 'Coffee Table', description: 'Comfortable seating area' },
    { icon: Bed, title: 'King Size Bed', description: 'Luxurious bedding for perfect rest' },
    { icon: Bath, title: 'Modern Bathroom', description: 'Clean and well-appointed facilities' }
  ];

  const stats = [
    { number: '12+', label: 'Rooms Available' },
    { number: '24/7', label: 'Service Available' },
    { number: '4.9★', label: 'Guest Rating' },
    { number: '100%', label: 'Guest Satisfaction' }
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <HeroSection />

      {/* Stats Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index} className="transform hover:scale-105 transition-transform duration-300">
                <div className="text-3xl md:text-4xl font-bold mb-2">{stat.number}</div>
                <div className="text-gray-200">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Preview */}
      <section className="py-16 bg-gradient-to-r from-gray-50 to-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="transform hover:translate-x-2 transition-transform duration-300">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
                Experience Comfort & Luxury in Faizabad
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Hotel Veda Inn offers an exceptional stay experience in the heart of Faizabad, 
                with easy access to the holy city of Ayodhya. Our hotel combines modern amenities 
                with traditional Indian hospitality to ensure your comfort and satisfaction.
              </p>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                Whether you're visiting for pilgrimage, business, or leisure, our Super Deluxe 
                rooms and Family Suites provide the perfect sanctuary with all modern conveniences 
                and personalized service.
              </p>
              <a
                href="https://wa.me/917755885539"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-primary hover:bg-primary/90 text-white px-8 py-3 rounded-lg font-medium transition-all duration-300 hover:shadow-lg transform hover:scale-105 inline-block"
              >
                Book Now
              </a>
            </div>
            <div className="relative group">
              <img
                src="https://images.unsplash.com/photo-1721322800607-8c38375eef04"
                alt="Hotel Veda Inn Luxury Room"
                className="w-full h-[400px] object-cover rounded-lg shadow-lg group-hover:shadow-2xl transition-all duration-300 transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-primary/20 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Hotel Facilities */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Hotel Facilities</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Experience world-class amenities and services designed for your comfort and convenience
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {facilities.map((facility, index) => (
              <Card key={index} className="text-center hover:shadow-xl transition-all duration-300 transform hover:scale-105 group">
                <CardHeader>
                  <facility.icon className="h-12 w-12 text-primary mx-auto mb-4 group-hover:scale-110 transition-transform duration-300" />
                  <CardTitle className="text-xl group-hover:text-primary transition-colors duration-300">{facility.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{facility.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Room Types Preview */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Our Room Types</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Choose from our carefully designed Super Deluxe rooms and spacious Family Suites
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:scale-105 group">
              <div className="h-64 bg-gradient-to-r from-primary/10 to-primary/20 flex items-center justify-center group-hover:from-primary/20 group-hover:to-primary/30 transition-all duration-300">
                <Bed className="h-16 w-16 text-primary group-hover:scale-110 transition-transform duration-300" />
              </div>
              <CardHeader>
                <CardTitle className="text-2xl group-hover:text-primary transition-colors duration-300">Super Deluxe Rooms</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Elegantly designed rooms with modern amenities, perfect for couples and business travelers.
                </p>
                <ul className="text-sm text-gray-600 space-y-2 mb-6">
                  <li>• King size bed with premium linens</li>
                  <li>• Air conditioning and flat screen TV</li>
                  <li>• Free WiFi and coffee table</li>
                  <li>• Modern bathroom with geyser</li>
                </ul>
                <a
                  href="https://wa.me/917755885539"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-primary hover:bg-primary/90 text-white px-6 py-2 rounded-lg font-medium transition-all duration-300 hover:shadow-lg transform hover:scale-105 inline-block w-full text-center"
                >
                  Book Now
                </a>
              </CardContent>
            </Card>

            <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:scale-105 group">
              <div className="h-64 bg-gradient-to-r from-primary/10 to-primary/20 flex items-center justify-center group-hover:from-primary/20 group-hover:to-primary/30 transition-all duration-300">
                <Users className="h-16 w-16 text-primary group-hover:scale-110 transition-transform duration-300" />
              </div>
              <CardHeader>
                <CardTitle className="text-2xl group-hover:text-primary transition-colors duration-300">Family Suites</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Spacious suites designed for families, offering comfort and convenience for all ages.
                </p>
                <ul className="text-sm text-gray-600 space-y-2 mb-6">
                  <li>• Multiple beds with extra space</li>
                  <li>• Separate living area with sofa</li>
                  <li>• Family-friendly amenities</li>
                  <li>• All modern conveniences included</li>
                </ul>
                <a
                  href="https://wa.me/917755885539"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-primary hover:bg-primary/90 text-white px-6 py-2 rounded-lg font-medium transition-all duration-300 hover:shadow-lg transform hover:scale-105 inline-block w-full text-center"
                >
                  Book Now
                </a>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Location */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Our Location</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Strategically located in Faizabad with easy access to Ayodhya and major attractions
            </p>
          </div>
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="transform hover:translate-x-2 transition-transform duration-300">
              <div className="flex items-center space-x-3 mb-6">
                <MapPin className="h-6 w-6 text-primary" />
                <div>
                  <h3 className="text-xl font-semibold text-gray-800">Hotel Veda Inn</h3>
                  <p className="text-gray-600">Fatehganj Devkali Rd, Deokali, Faizabad, Uttar Pradesh 224001</p>
                </div>
              </div>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Our hotel is conveniently located on Fatehganj Devkali Road, providing easy access to 
                the holy city of Ayodhya, railway stations, bus terminals, and major tourist attractions. 
                The strategic location makes us the perfect base for your spiritual journey or business trip.
              </p>
              <Button 
                asChild
                size="lg" 
                className="bg-primary hover:bg-primary/90 transform hover:scale-105 transition-all duration-300"
              >
                <a 
                  href="https://www.google.com/maps/place/Veda+INN+by+Chrysdorf/@26.7686832,82.1688408,17z/data=!4m10!3m9!1s0x399a08802a8a01b1:0xf12f02b6288026b7!5m3!1s2025-07-01!4m1!1i2!8m2!3d26.7686832!4d82.1688408!16s%2Fg%2F11xdr1xxl0?entry=ttu&g_ep=EgoyMDI1MDUyOC4wIKXMDSoASAFQAw%3D%3D"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  View on Google Maps
                </a>
              </Button>
            </div>
            <div className="relative">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3583.8359580000003!2d82.16884!3d26.7686832!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399a08802a8a01b1%3A0xf12f02b6288026b7!2sVeda%20INN%20by%20Chrysdorf!5e0!3m2!1sen!2sin!4v1620000000000!5m2!1sen!2sin"
                width="100%"
                height="400"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300"
                title="Hotel Veda Inn Location"
              />
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
