
import React from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { MapPin, Phone, Mail, Clock, Car, Building, Users, CreditCard } from 'lucide-react';

const Contact = () => {
  const contactInfo = [
    {
      icon: MapPin,
      title: 'Our Location',
      content: 'Fatehganj Devkali Rd, Deokali, Faizabad, Uttar Pradesh 224001',
      action: 'Get Directions'
    },
    {
      icon: Phone,
      title: 'Call Us',
      content: '+91 77558 85539',
      action: 'Call Now'
    },
    {
      icon: Mail,
      title: 'Email Us',
      content: 'info@hotelvedainn.com',
      action: 'Send Email'
    },
    {
      icon: Clock,
      title: 'Front Desk Hours',
      content: '24/7 Available',
      action: 'Always Open'
    }
  ];

  const services = [
    { icon: Car, title: 'Cab Service', description: 'Airport and city transfers available' },
    { icon: Building, title: 'Room Service', description: '24-hour in-room dining service' },
    { icon: Users, title: 'Travel Desk', description: 'Local tour and pilgrimage assistance' },
    { icon: CreditCard, title: 'Card Payment', description: 'All major cards accepted' }
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-primary to-primary/80">
        <div className="container mx-auto px-4 pt-16">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Contact Hotel Veda Inn</h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-8">
              Get in Touch with the Premier Hotel in Faizabad Near Ayodhya
            </p>
            <p className="text-lg max-w-4xl mx-auto">
              Whether you're planning a spiritual journey to Ayodhya, a business trip, or a family vacation, 
              Hotel Veda Inn is here to assist you with all your accommodation needs. Our dedicated team is 
              available 24/7 to ensure your stay is comfortable and memorable.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">How to Reach Us</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Hotel Veda Inn is conveniently located in Faizabad with easy access to Ayodhya's major attractions. 
              Contact us through any of the following methods for instant assistance.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {contactInfo.map((info, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <info.icon className="h-12 w-12 text-primary mx-auto mb-4" />
                  <CardTitle className="text-xl">{info.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{info.content}</p>
                  <Button variant="outline" size="sm">
                    {info.action}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form and Map */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <h2 className="text-3xl font-bold mb-6 text-gray-800">Send Us a Message</h2>
              <p className="text-lg text-gray-600 mb-8">
                Have questions about our rooms, facilities, or need assistance with your booking? 
                Fill out the form below and our team will get back to you within 24 hours.
              </p>
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      First Name *
                    </label>
                    <Input placeholder="Enter your first name" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Last Name *
                    </label>
                    <Input placeholder="Enter your last name" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address *
                  </label>
                  <Input type="email" placeholder="Enter your email address" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Phone Number *
                  </label>
                  <Input type="tel" placeholder="Enter your phone number" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Subject
                  </label>
                  <Input placeholder="What is this regarding?" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Message *
                  </label>
                  <Textarea 
                    placeholder="Tell us how we can help you..." 
                    rows={5}
                  />
                </div>
                <Button size="lg" className="w-full bg-primary hover:bg-primary/90">
                  Send Message
                </Button>
              </form>
            </div>

            {/* Map and Location Info */}
            <div>
              <h2 className="text-3xl font-bold mb-6 text-gray-800">Our Location</h2>
              <div className="bg-gray-200 h-64 rounded-lg mb-6 flex items-center justify-center">
                <p className="text-gray-500">Interactive Map Loading...</p>
              </div>
              <div className="space-y-4">
                <h3 className="text-xl font-semibold text-gray-800">Hotel Veda Inn</h3>
                <p className="text-gray-600">
                  Fatehganj Devkali Rd, Deokali, Faizabad, Uttar Pradesh 224001
                </p>
                <p className="text-gray-600">
                  Our hotel is strategically located in the heart of Faizabad, providing easy access to:
                </p>
                <ul className="space-y-2 text-gray-600">
                  <li>• Ayodhya Ram Mandir - 15 minutes drive</li>
                  <li>• Faizabad Railway Station - 10 minutes drive</li>
                  <li>• Faizabad Bus Terminal - 8 minutes drive</li>
                  <li>• Saryu River Ghats - 20 minutes drive</li>
                  <li>• Local Markets - 5 minutes walk</li>
                </ul>
                <Button 
                  asChild
                  size="lg" 
                  className="w-full bg-primary hover:bg-primary/90"
                >
                  <a 
                    href="https://www.google.com/maps/place/Veda+INN+by+Chrysdorf/@26.7686832,82.1688408,17z/data=!4m10!3m9!1s0x399a08802a8a01b1:0xf12f02b6288026b7!5m3!1s2025-07-01!4m1!1i2!8m2!3d26.7686832!4d82.1688408!16s%2Fg%2F11xdr1xxl0?entry=ttu&g_ep=EgoyMDI1MDUyOC4wIKXMDSoASAFQAw%3D%3D"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    View on Google Maps
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Personal Services</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Beyond accommodation, we offer personalized services to make your stay in Faizabad and visit to Ayodhya seamless and comfortable.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <service.icon className="h-12 w-12 text-primary mx-auto mb-4" />
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Frequently Asked Questions</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Find answers to common questions about Hotel Veda Inn, our services, and policies.
            </p>
          </div>
          <div className="max-w-4xl mx-auto space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>What are your check-in and check-out times?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Standard check-in time is 12:00 PM and check-out time is 11:00 AM. Early check-in after 10:00 AM 
                  is subject to availability. Late check-out between 11:00 AM and 1:00 PM is complimentary, 
                  subject to availability.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Do you provide transportation to Ayodhya?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Yes, we offer cab services for transportation to Ayodhya and other local attractions. 
                  Our travel desk can arrange comfortable vehicles for your pilgrimage and sightseeing needs.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>What payment methods do you accept?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  We accept all major credit cards, debit cards, UPI payments, and cash. The full booking amount 
                  needs to be paid at the time of check-in.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Contact;
