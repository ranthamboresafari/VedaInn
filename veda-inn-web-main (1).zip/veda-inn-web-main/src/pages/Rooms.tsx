
import React from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Wifi, 
  Tv, 
  Coffee, 
  Bed, 
  Bath, 
  Car,
  Utensils,
  Shield,
  Wind,
  Users,
  Star,
  CheckCircle
} from 'lucide-react';

const Rooms = () => {
  const roomTypes = [
    {
      name: 'Super Deluxe Room',
      images: [
        '/lovable-uploads/e5227926-ea9d-4dd8-b2b8-3ad3d3ac27b0.png',
        '/lovable-uploads/f418b3df-aa03-4895-93cd-7881ff4ebcd6.png',
        '/lovable-uploads/84b35ff5-c8e8-4fb4-8e8b-f147ba850db7.png'
      ],
      description: 'Experience luxury and comfort in our elegantly designed Super Deluxe rooms, perfect for couples and business travelers visiting Ayodhya.',
      features: [
        'King Size Bed with premium linens',
        'Air Conditioning with individual controls',
        'Flat Screen TV with satellite channels',
        'Free High-Speed WiFi',
        'Modern bathroom with geyser',
        'Coffee table and comfortable seating',
        'Wardrobe and storage space',
        'Bedside table with reading lights',
        'Intercom facility',
        'Dressing mirror',
        'Daily housekeeping'
      ],
      amenities: [
        { icon: Bed, text: 'King Size Bed' },
        { icon: Wind, text: 'AC Room' },
        { icon: Tv, text: 'Flat Screen TV' },
        { icon: Wifi, text: 'Free WiFi' },
        { icon: Bath, text: 'Modern Bathroom' },
        { icon: Coffee, text: 'Coffee Table' }
      ],
      price: 'Starting from ₹2,500/night',
      capacity: '2 Adults'
    },
    {
      name: 'Family Suite',
      images: [
        '/lovable-uploads/84b35ff5-c8e8-4fb4-8e8b-f147ba850db7.png',
        '/lovable-uploads/a2af81c5-5e23-48ae-80ed-0eb7bbcab971.png',
        '/lovable-uploads/597d0a37-e895-4b34-833e-541f1fa32ae9.png'
      ],
      description: 'Spacious family suites designed for families and groups visiting the holy city of Ayodhya, offering comfort and convenience for all ages.',
      features: [
        'Multiple beds with extra space',
        'Separate living area with sofa',
        'Air Conditioning throughout',
        'Large flat screen TV',
        'Free High-Speed WiFi',
        'Spacious bathroom with modern fittings',
        'Coffee/tea making facilities',
        'Ample storage with wardrobes',
        'Family-friendly amenities',
        'Room service available',
        'Elevator access',
        'Complimentary breakfast'
      ],
      amenities: [
        { icon: Users, text: 'Family Space' },
        { icon: Bed, text: 'Multiple Beds' },
        { icon: Wind, text: 'AC Throughout' },
        { icon: Tv, text: 'Large Screen TV' },
        { icon: Wifi, text: 'Free WiFi' },
        { icon: Utensils, text: 'Tea/Coffee' }
      ],
      price: 'Starting from ₹3,500/night',
      capacity: '4-6 Adults + Children'
    }
  ];

  const inRoomFacilities = [
    { icon: Wind, title: 'AC Room', description: 'Individual climate control for optimal comfort' },
    { icon: Coffee, title: 'Coffee Table', description: 'Comfortable seating area for relaxation' },
    { icon: Tv, title: 'Flat Screen TV', description: 'Entertainment with satellite channels' },
    { icon: Wifi, title: 'Free WiFi', description: 'High-speed internet connectivity' },
    { icon: Bath, title: 'Geyser', description: 'Hot water available 24/7' },
    { icon: Bed, title: 'King Size Bed', description: 'Premium bedding for restful sleep' },
    { icon: Shield, title: 'Wardrobe', description: 'Ample storage space for belongings' },
    { icon: Star, title: 'Premium Linens', description: 'High-quality bed linens and towels' }
  ];

  const policies = [
    {
      title: 'Check-in/Check-out Policy',
      details: [
        'Standard Check-in: 12:00 PM',
        'Standard Check-out: 11:00 AM',
        'Early check-in after 10:00 AM (subject to availability)',
        'Late check-out until 1:00 PM (complimentary, subject to availability)',
        'After 2:00 PM check-out: Extra night charges apply'
      ]
    },
    {
      title: 'Child Policy',
      details: [
        'Maximum 1 child up to 6 years: Free of charge',
        '1 infant up to 2 years: Free of charge',
        'Breakfast included as per plan selected',
        'No extra bed/mattress for free children',
        'Extra charges for children above 7 years'
      ]
    },
    {
      title: 'Identification Requirements',
      details: [
        'Valid photo ID required for all adults',
        'Accepted: Driving License, Voter ID, Passport, Ration Card, Aadhaar Card',
        'PAN Cards are not accepted',
        'Local and outstation IDs welcome',
        'Couple-friendly hotel policy'
      ]
    },
    {
      title: 'Payment Policy',
      details: [
        'Full payment at check-in',
        'All major credit/debit cards accepted',
        'UPI and cash payments welcome',
        'GST details cannot be modified post check-out',
        'Add GST details during booking'
      ]
    }
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-primary to-primary/80">
        <div className="container mx-auto px-4 pt-16">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Luxury Rooms & Suites at Hotel Veda Inn
            </h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-8">
              Experience Comfort and Elegance in the Heart of Faizabad Near Ayodhya
            </p>
            <p className="text-lg max-w-4xl mx-auto leading-relaxed">
              Discover our meticulously designed accommodations featuring modern amenities, 
              traditional hospitality, and serene ambiance perfect for your spiritual journey to Ayodhya. 
              Each room is crafted to provide the ultimate comfort and convenience for pilgrims, 
              business travelers, and families.
            </p>
          </div>
        </div>
      </section>

      {/* Room Types */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
              Choose Your Perfect Accommodation
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Select from our range of thoughtfully designed rooms and suites, 
              each offering distinct features to cater to different needs and preferences.
            </p>
          </div>

          {roomTypes.map((room, index) => (
            <div key={index} className="mb-16">
              <Card className="overflow-hidden hover:shadow-xl transition-shadow">
                <div className="grid lg:grid-cols-2 gap-0">
                  {/* Image Gallery */}
                  <div className="relative">
                    <div className="h-96 lg:h-full">
                      <img
                        src={room.images[0]}
                        alt={`${room.name} at Hotel Veda Inn`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="absolute top-4 left-4">
                      <span className="bg-primary text-white px-3 py-1 rounded-full text-sm font-semibold">
                        {room.capacity}
                      </span>
                    </div>
                  </div>

                  {/* Room Details */}
                  <div className="p-8">
                    <div className="mb-6">
                      <h3 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2">
                        {room.name}
                      </h3>
                      <p className="text-primary font-semibold text-lg mb-4">
                        {room.price}
                      </p>
                      <p className="text-gray-600 leading-relaxed mb-6">
                        {room.description}
                      </p>
                    </div>

                    {/* Amenities Icons */}
                    <div className="grid grid-cols-3 gap-4 mb-6">
                      {room.amenities.map((amenity, i) => (
                        <div key={i} className="flex items-center space-x-2">
                          <amenity.icon className="h-5 w-5 text-primary" />
                          <span className="text-sm text-gray-600">{amenity.text}</span>
                        </div>
                      ))}
                    </div>

                    {/* Features List */}
                    <div className="mb-6">
                      <h4 className="font-semibold text-gray-800 mb-3">Room Features:</h4>
                      <div className="grid grid-cols-1 gap-2">
                        {room.features.slice(0, 6).map((feature, i) => (
                          <div key={i} className="flex items-start space-x-2">
                            <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span className="text-sm text-gray-600">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Button size="lg" className="w-full bg-primary hover:bg-primary/90">
                      Book This Room
                    </Button>
                  </div>
                </div>
              </Card>
            </div>
          ))}
        </div>
      </section>

      {/* In-Room Facilities */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
              Premium In-Room Facilities
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Every room at Hotel Veda Inn comes equipped with modern amenities and facilities 
              designed to enhance your comfort and convenience during your stay.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {inRoomFacilities.map((facility, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <facility.icon className="h-12 w-12 text-primary mx-auto mb-4" />
                  <CardTitle className="text-lg">{facility.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-sm">{facility.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
              Additional Services & Amenities
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Beyond comfortable accommodations, we offer comprehensive services to make your stay memorable.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Utensils className="h-12 w-12 text-primary mx-auto mb-4" />
                <CardTitle>Complimentary Breakfast</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Start your day with our complimentary breakfast featuring local and continental options, 
                  perfect fuel for your Ayodhya pilgrimage.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Car className="h-12 w-12 text-primary mx-auto mb-4" />
                <CardTitle>Free Parking</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Secure, complimentary parking available for all guests. 
                  Your vehicle safety is our priority throughout your stay.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Shield className="h-12 w-12 text-primary mx-auto mb-4" />
                <CardTitle>24/7 Security</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Round-the-clock security ensures your safety and peace of mind, 
                  allowing you to focus on your spiritual journey.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Hotel Policies */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
              Hotel Policies & Guidelines
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Please review our policies to ensure a smooth and comfortable stay at Hotel Veda Inn.
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            {policies.map((policy, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-xl text-primary">{policy.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {policy.details.map((detail, i) => (
                      <li key={i} className="flex items-start space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-600 text-sm">{detail}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Booking CTA */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
              Ready to Experience Comfort and Luxury?
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Book your stay at Hotel Veda Inn and enjoy world-class accommodations in the heart of Faizabad, 
              with easy access to the sacred temples of Ayodhya. Our dedicated team is ready to make your 
              pilgrimage journey comfortable and memorable.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-primary hover:bg-primary/90">
                Book Now - Best Rates Guaranteed
              </Button>
              <Button size="lg" variant="outline">
                Call +91 77558 85539
              </Button>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Rooms;
