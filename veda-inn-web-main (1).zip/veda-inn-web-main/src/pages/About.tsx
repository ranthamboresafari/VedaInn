
import React from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent } from '@/components/ui/card';
import { Shield, Users, Award, Heart, MapPin, Clock, Star, Sparkles } from 'lucide-react';

const About = () => {
  const values = [
    {
      icon: Heart,
      title: 'Hospitality',
      description: 'We believe in treating every guest as family, providing warm and personalized service that makes your stay memorable.'
    },
    {
      icon: Shield,
      title: 'Quality',
      description: 'From our rooms to our dining, every aspect of Hotel Veda Inn is designed to meet the highest standards of quality and comfort.'
    },
    {
      icon: Users,
      title: 'Community',
      description: 'As a locally rooted hotel, we are committed to serving our community and contributing to the cultural heritage of Faizabad and Ayodhya.'
    },
    {
      icon: Award,
      title: 'Excellence',
      description: 'Our commitment to excellence drives us to continuously improve and exceed guest expectations in every interaction.'
    }
  ];

  const achievements = [
    { icon: Star, number: '4.9/5', label: 'Guest Rating' },
    { icon: Users, number: '1000+', label: 'Happy Guests' },
    { icon: Clock, number: '24/7', label: 'Service Available' },
    { icon: Sparkles, number: '100%', label: 'Satisfaction Rate' }
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-primary to-primary/80 overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto px-4 pt-16 relative z-10">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 animate-fade-in">About Hotel Veda Inn</h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto animate-fade-in">
              Your Gateway to Comfort and Luxury in the Holy Land of Ayodhya
            </p>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 w-full h-16 bg-gradient-to-t from-white to-transparent"></div>
      </section>

      {/* Achievements Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {achievements.map((achievement, index) => (
              <div key={index} className="transform hover:scale-105 transition-all duration-300 group">
                <achievement.icon className="h-12 w-12 text-primary mx-auto mb-4 group-hover:scale-110 transition-transform duration-300" />
                <div className="text-3xl md:text-4xl font-bold mb-2 text-gray-800">{achievement.number}</div>
                <div className="text-gray-600">{achievement.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div className="order-2 lg:order-1">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
                Where Sacred Traditions Meet Modern Luxury
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Nestled in the spiritual heartland of Faizabad, Hotel Veda Inn isn't just a place to stay—it's your sanctuary 
                of comfort in the sacred realm of Lord Rama. Our hotel seamlessly blends the profound spirituality of Ayodhya 
                with contemporary luxury, creating an atmosphere where every moment becomes a cherished memory.
              </p>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                From the moment you step through our doors, you're enveloped in an ambiance of tranquility and warmth. 
                Our team of hospitality artisans curates experiences that honor both your spiritual journey and your desire 
                for comfort, ensuring that your pilgrimage or business trip transcends ordinary travel.
              </p>
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-primary">
                <p className="text-gray-600 italic leading-relaxed">
                  "At Hotel Veda Inn, we don't just provide accommodation—we craft experiences that resonate with your soul 
                  and create stories you'll treasure forever."
                </p>
                <p className="text-sm text-primary font-semibold mt-3">— Hotel Veda Inn Management</p>
              </div>
            </div>
            <div className="order-1 lg:order-2 relative group">
              <img
                src="https://images.unsplash.com/photo-1518005020951-eccb494ad742"
                alt="Hotel Veda Inn Luxury Experience"
                className="w-full h-[500px] object-cover rounded-lg shadow-lg group-hover:shadow-2xl transition-all duration-300 transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
          </div>

          {/* Our Values */}
          <div className="mb-16">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">The Pillars of Our Promise</h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                These core values shape every interaction, every service, and every moment of your stay with us.
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.map((value, index) => (
                <Card key={index} className="text-center p-6 hover:shadow-xl transition-all duration-300 transform hover:scale-105 group border-0 shadow-md">
                  <CardContent className="pt-6">
                    <div className="relative">
                      <value.icon className="h-12 w-12 text-primary mx-auto mb-4 group-hover:scale-110 transition-transform duration-300" />
                      <div className="absolute inset-0 bg-primary/10 rounded-full w-16 h-16 mx-auto -mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    </div>
                    <h3 className="text-xl font-semibold mb-3 text-gray-800 group-hover:text-primary transition-colors duration-300">{value.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{value.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Our Story */}
          <div className="bg-gradient-to-r from-white to-gray-100 rounded-2xl p-8 md:p-12 shadow-lg">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-8">
                <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Our Sacred Journey</h2>
                <div className="w-24 h-1 bg-primary mx-auto rounded-full"></div>
              </div>
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div>
                  <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                    Hotel Veda Inn was born from a vision to bridge the ancient and the modern—to create a haven where 
                    spiritual seekers and modern travelers alike could find solace, comfort, and inspiration. Our founders 
                    understood that visiting Ayodhya is more than tourism; it's a pilgrimage of the heart.
                  </p>
                  <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                    Every design choice, every service offering, and every team member selection was made with the intention 
                    of honoring the sacred significance of this land while providing the contemporary amenities that today's 
                    discerning travelers expect.
                  </p>
                  <a
                    href="https://wa.me/917755885539"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-primary hover:bg-primary/90 text-white px-8 py-3 rounded-lg font-medium transition-all duration-300 hover:shadow-lg transform hover:scale-105 inline-block"
                  >
                    Begin Your Journey
                  </a>
                </div>
                <div className="relative">
                  <div className="bg-gradient-to-r from-primary/20 to-primary/30 rounded-lg p-8 text-center">
                    <MapPin className="h-16 w-16 text-primary mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">Perfect Location</h3>
                    <p className="text-gray-600">
                      Strategically positioned to offer easy access to all major temples and attractions in Ayodhya, 
                      while providing a peaceful retreat from the bustling pilgrimage crowds.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Experience the Difference?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
            Join thousands of satisfied guests who have made Hotel Veda Inn their home away from home in the sacred city.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/917755885539"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white text-primary px-8 py-3 rounded-lg font-medium hover:bg-gray-100 transition-all duration-300 hover:shadow-lg transform hover:scale-105 inline-block"
            >
              Book Your Stay Now
            </a>
            <a
              href="tel:+917755885539"
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-medium hover:bg-white hover:text-primary transition-all duration-300 hover:shadow-lg transform hover:scale-105 inline-block"
            >
              Call Us Directly
            </a>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default About;
